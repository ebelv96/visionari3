// vikey-export.js
//
// Si logga su my.vikey.it e replica il flusso manuale:
// Prenotazioni > Esporta > Lista Prenotazioni > range date > bottone Esporta.
// Vikey manda poi il CSV via email da sola, esattamente come nell'export manuale.
// Questo script non gestisce l'invio email: quello lo fa Vikey.
//
// Variabili d'ambiente richieste:
//   VIKEY_EMAIL    - email di login Vikey
//   VIKEY_PASSWORD - password di login Vikey
//
// Uso locale (per test / debug dei selettori):
//   HEADLESS=false node vikey-export.js
//
// Uso in CI:
//   node vikey-export.js

const { chromium } = require('playwright');

const VIKEY_EMAIL = process.env.VIKEY_EMAIL;
const VIKEY_PASSWORD = process.env.VIKEY_PASSWORD;
const HEADLESS = process.env.HEADLESS !== 'false';

// Data di fine range: generosa e fissa, non serve leggerla dinamicamente
// dalla tabella prenotazioni. Aggiorna questo valore ogni tanto (es. una
// volta l'anno) se vuoi tenerlo "vicino" al presente, ma non è necessario
// per correttezza: semplicemente non esisteranno prenotazioni oltre questa data.
const START_DATE = '01/01/2025';
const END_DATE = '31/12/2028';

if (!VIKEY_EMAIL || !VIKEY_PASSWORD) {
  console.error('Mancano VIKEY_EMAIL e/o VIKEY_PASSWORD nelle variabili d\'ambiente.');
  process.exit(1);
}

async function run() {
  const browser = await chromium.launch({ headless: HEADLESS });
  const page = await browser.newPage();

  try {
    console.log('Apro my.vikey.it...');
    await page.goto('https://my.vikey.it/', { waitUntil: 'networkidle' });

    console.log('Login...');
    // Selettori "robusti" basati su label/testo. Se Vikey usa markup diverso,
    // vanno aggiustati qui dopo un giro di test in locale con HEADLESS=false.
    await page.getByLabel(/email/i).fill(VIKEY_EMAIL);
    await page.getByLabel(/password/i).fill(VIKEY_PASSWORD);
    await page.getByRole('button', { name: /accedi|login|entra/i }).click();

    await page.waitForLoadState('networkidle');
    console.log('Login effettuato.');

    console.log('Navigo su Prenotazioni...');
    await page.getByRole('link', { name: /prenotazioni/i }).click();
    await page.waitForLoadState('networkidle');

    console.log('Apro Esporta...');
    await page.getByRole('button', { name: /esporta/i }).click();
    await page.waitForLoadState('networkidle');

    console.log('Seleziono Lista Prenotazioni...');
    await page.getByText(/lista prenotazioni/i).click();
    await page.waitForLoadState('networkidle');

    console.log('Imposto il range date...');
    // Assumo due campi data separati (da / a). Da verificare e aggiustare
    // se Vikey usa un date-picker diverso (es. un unico campo range).
    const dateInputs = page.locator('input[type="text"], input[type="date"]');
    await dateInputs.nth(0).fill(START_DATE);
    await dateInputs.nth(1).fill(END_DATE);

    console.log('Clicco Esporta...');
    await page.getByRole('button', { name: /^esporta$/i }).click();

    // Diamo tempo a Vikey di processare e inviare l'email
    await page.waitForTimeout(5000);

    console.log('Export completato. Vikey invierà il CSV via email a breve.');
  } catch (err) {
    console.error('Errore durante l\'export:', err);
    // Screenshot di debug, utile se lo step CI lo carica come artifact
    try {
      await page.screenshot({ path: 'vikey-export-error.png', fullPage: true });
    } catch (screenshotErr) {
      console.error('Impossibile salvare screenshot:', screenshotErr);
    }
    process.exitCode = 1;
  } finally {
    await browser.close();
  }
}

run();
